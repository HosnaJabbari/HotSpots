/* For C compiler */

//#ifdef __cplusplus
//extern "C" {
//#endif
  float score( int len, char*s,  short*p, int TRACE, int energyModel);  // ADDED: energyModel parameter
  int F2(  int len,  char* s,
	   int i,  int k,  int l,  int j);
  int sPair(  int len,  char* s0,   int i,   int j);
void Char_To_Intsequence(const int len, const char*const csequence, int * sequence);
//#ifdef __cplusplus
//}
//#endif


